# DBB Database Migration Utility

The purpose of this utility is to facilitate the migration of the DBB database between different database management systems, like Derby, Db2 and Db2z.

Databases schemas of DBB 1.1.x and DBB 2.0 are compatible.
In the current release of this utility, the supported DBB schemas are:
* DBB 1.1.3
* DBB 2.0



## Solution outline

This CLI-driven utility:
* prompts the user for the source and the target database connection details,
* creates a connection to the source DBMS and the target DBMS system,
* copy the full content of the source database to the target database, by selecting and inserting the required data.

It is able to incrementally update the target system with additions.

## Prerequisites 

* Source and target DBB schemas need to match. (Note: No validation today.)

## Utility usage

### Prerequisites

* Credentials to access the source and target database management systems.
* The version of the DBB database schema of the source and target database management system need to match.
* The target database needs to be setup, but without any contents. This means the database and the DBB schema including the tables and indexes were created successfully.

### Invokation

1. Identify the locations of the necessary libraries: Derby libraries and Db2 libraries are required to setup the JDBC connections to these Database Management systems.
 
2. In a command prompt, use the following command to run the utility while configuring the classpath to include the Derby and Db2 libraries.

```
java -cp dbb.database.migration.util-0.9.1_20230328.jar:/opt/DBB-1.1.3-GitLab/wlp/usr/shared/resources/db2/*:/opt/DBB-1.1.3-GitLab/wlp/usr/shared/resources/derby/lib/* com.ibm.dbb.database.migration.MigrateDatabase
```

3. Provide the necessary information about the source and target database.
   Typically the derby system, does not require user and password, just hint <enter>. Please note that the password is displayed in clear text.

```
* DBB Database migration util *
* --------------------------  *
** Prompting to specify source and target dbms information
 Enter your source dbms information
  Source dbms [Derby, Db2, Db2z]: Derby
  url: jdbc:derby://10.3.20.96:1527//opt/DBB-1.1.3-GitLab/wlp/usr/servers/dbb/DBB_DATABASE_NOV
  userid:
  password:
 Enter your target dbms information
  Target dbms [Derby, Db2, Db2z]: Db2
  url: jdbc:db2://10.3.20.201:4740/MOPDBC0
  userid: DBEHM
  password: xxxxxxx
** Establishing JDBC connections
...
```


## Tips and tricks

### Start DERBY Network Server to allow remote access

Derby does not automatically open a port for JDBC. You might want to start the [DERBY Network Server](https://db.apache.org/derby/docs/10.5/adminguide/tadmincbdjhhfd.html) which is included in the install.  

```
java -jar /opt/DBB-1.1.3/wlp/usr/shared/resources/derby/lib/derbyrun.jar server start -noSecurityManager -h 10.3.20.96  &
```